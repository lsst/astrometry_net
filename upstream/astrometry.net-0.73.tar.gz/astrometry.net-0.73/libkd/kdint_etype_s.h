/*
# This file is part of libkd.
# Licensed under a 3-clause BSD style license - see LICENSE
*/

typedef u16 etype;

#define ETYPE_INTEGER 1

#define ETYPE_MAX  0xffffu
#define ETYPE_MIN  0

#define ETYPE s
#define ETYPE_M s

//#define ETYPE_KDT_DATA  KDT_DATA_U16

